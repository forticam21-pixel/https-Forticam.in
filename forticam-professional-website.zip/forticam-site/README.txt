FORTICAM — PROFESSIONAL WEBSITE
================================

CONTENTS
- index.html: responsive website homepage
- assets/: FORTICAM photos, product visuals and promotional video

LOCAL PREVIEW
1. Extract this ZIP.
2. Open forticam-site/index.html in a modern browser.
3. Keep the assets folder beside index.html.

QUICK PUBLISH — NETLIFY (COMMAND LINE)
--------------------------------------
Prerequisites: Node.js installed, a Netlify account, and access to the target Netlify site.

First-time setup (run from this folder):
    npx netlify-cli login
    npx netlify-cli link

Publish future updates:
    npx netlify-cli deploy --prod --dir=.

The command publishes the current folder to the Netlify site linked to your account.
If prompted, choose the existing FORTICAM site. Do not share your Netlify login token.

PUBLISH WITHOUT COMMAND LINE
----------------------------
1. Sign in to Netlify.
2. Open the correct FORTICAM site.
3. Open Deploys and choose the manual deploy / drag-and-drop area.
4. Upload the extracted forticam-site folder (not the ZIP file).
5. Confirm that index.html and the assets folder are at the top level.

GITHUB PUBLISHING
-----------------
For GitHub-connected Netlify deployment, upload the CONTENTS of forticam-site
(index.html and assets/) to the repository root, then connect that repository
to Netlify. Do not upload only the ZIP file: GitHub does not extract ZIP files.

IMPORTANT ABOUT LIVE CAMERAS
----------------------------
The photo gallery displays all five supplied FORTICAM images and the video.
A real CCTV live feed is different from a photo gallery. It requires a compatible
camera/NVR stream or vendor API, secure authentication, and permission to view it.
Never place camera passwords, private stream URLs, or access tokens in public HTML.
The website therefore describes compatible live viewing but does not pretend that
a live camera feed is connected.

CONTACT DETAILS CURRENTLY SHOWN
-------------------------------
Phone: +91 92172 95528
Email: forticam21@gmail.com
Address: Sector 86, BPTP World Street, Faridabad, Haryana 121006

Please verify contact details before publishing.
